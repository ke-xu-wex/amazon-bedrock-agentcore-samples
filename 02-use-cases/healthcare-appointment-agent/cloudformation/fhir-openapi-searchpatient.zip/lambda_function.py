import json
from datetime import datetime, timedelta
import random

# Mock data - Patient records
MOCK_PATIENTS = {
    "pediatric-patient-001": {
        "resourceType": "Patient",
        "id": "pediatric-patient-001",
        "active": True,
        "name": [
            {
                "use": "official",
                "family": "Doe",
                "given": ["John"]
            }
        ],
        "gender": "male",
        "birthDate": "2023-07-10",
        "address": [
            {
                "use": "home",
                "line": ["123 Maple Street"],
                "city": "Springfield",
                "state": "IL",
                "postalCode": "62701",
                "country": "USA"
            }
        ]
    },
    "adult-patient-001": {
        "resourceType": "Patient",
        "id": "adult-patient-001",
        "active": True,
        "name": [
            {
                "use": "official",
                "family": "Doe",
                "given": ["Richard"]
            }
        ],
        "gender": "male",
        "birthDate": "1985-07-10",
        "address": [
            {
                "use": "home",
                "line": ["123 Maple Street"],
                "city": "Springfield",
                "state": "IL",
                "postalCode": "62701",
                "country": "USA"
            }
        ]
    }
}

# Mock data - Immunization records
MOCK_IMMUNIZATIONS = [
    {
        "resourceType": "Immunization",
        "id": "imm-001",
        "status": "completed",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "10",
                    "display": "IPV"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2023-09-15",
        "primarySource": True
    },
    {
        "resourceType": "Immunization",
        "id": "imm-002",
        "status": "completed",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "20",
                    "display": "DTaP"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2023-09-15",
        "primarySource": True
    },
    {
        "resourceType": "Immunization",
        "id": "imm-003",
        "status": "completed",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "133",
                    "display": "PCV13"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2024-01-10",
        "primarySource": True
    },
    {
        "resourceType": "Immunization",
        "id": "imm-004",
        "status": "not-done",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "03",
                    "display": "MMR"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2025-08-15",
        "statusReason": {
            "coding": [
                {
                    "system": "http://terminology.hl7.org/CodeSystem/v3-ActReason",
                    "code": "PATOBJ",
                    "display": "Patient Objection"
                }
            ]
        }
    },
    {
        "resourceType": "Immunization",
        "id": "imm-005",
        "status": "not-done",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "21",
                    "display": "Varicella"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2025-08-15",
        "statusReason": {
            "coding": [
                {
                    "system": "http://terminology.hl7.org/CodeSystem/v3-ActReason",
                    "code": "MEDPREC",
                    "display": "Medical Precaution"
                }
            ]
        }
    },
    {
        "resourceType": "Immunization",
        "id": "imm-006",
        "status": "completed",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "17",
                    "display": "Hib"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2024-03-20",
        "primarySource": True
    },
    {
        "resourceType": "Immunization",
        "id": "imm-007",
        "status": "completed",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "08",
                    "display": "Hepatitis B"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2023-08-10",
        "primarySource": True
    },
    {
        "resourceType": "Immunization",
        "id": "imm-008",
        "status": "completed",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "85",
                    "display": "Hepatitis A"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2024-02-15",
        "primarySource": True
    },
    {
        "resourceType": "Immunization",
        "id": "imm-009",
        "status": "not-done",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "94",
                    "display": "MMR-Varicella"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2025-08-15",
        "statusReason": {
            "coding": [
                {
                    "system": "http://terminology.hl7.org/CodeSystem/v3-ActReason",
                    "code": "PATOBJ",
                    "display": "Patient Objection"
                }
            ]
        }
    },
    {
        "resourceType": "Immunization",
        "id": "imm-010",
        "status": "completed",
        "vaccineCode": {
            "coding": [
                {
                    "system": "http://hl7.org/fhir/sid/cvx",
                    "code": "88",
                    "display": "Influenza"
                }
            ]
        },
        "patient": {
            "reference": "Patient/pediatric-patient-001"
        },
        "occurrenceDateTime": "2024-01-15",
        "primarySource": True
    }
]

# Mock data - Practitioner
MOCK_PRACTITIONER = {
    "resourceType": "Practitioner",
    "id": "prac-001",
    "active": True,
    "name": [
        {
            "use": "official",
            "family": "Johnson",
            "given": ["Sarah"],
            "prefix": ["Dr."]
        }
    ],
    "gender": "female",
    "qualification": [
        {
            "code": {
                "coding": [
                    {
                        "system": "http://terminology.hl7.org/CodeSystem/v2-0360",
                        "code": "MD",
                        "display": "Doctor of Medicine"
                    }
                ]
            }
        }
    ]
}


def get_named_parameter(event, name):
    """
    Get a parameter from the lambda event
    """
    if name in event:
        return event[name]
    else:
        return None


def get_patient_emr(patientId):
    """
    Get/Read a single patient resource - MOCK DATA VERSION
    
    Args:
        patientId (string): Identifier for the patient
    """
    print(f"Fetching mock patient data for: {patientId}")
    
    if patientId in MOCK_PATIENTS:
        return MOCK_PATIENTS[patientId]
    else:
        return {
            "resourceType": "OperationOutcome",
            "issue": [
                {
                    "severity": "error",
                    "code": "not-found",
                    "diagnostics": f"Patient with id {patientId} not found"
                }
            ]
        }


def search_patient_emr(addressState):
    """
    Search patients resources by state - MOCK DATA VERSION
    
    Args:
        addressState (string): Value of state based on which patients need to be searched
    """
    print(f"Searching mock patients by state: {addressState}")
    
    matching_patients = []
    for patient_id, patient_data in MOCK_PATIENTS.items():
        if patient_data.get("address"):
            for address in patient_data["address"]:
                if address.get("state", "").upper() == addressState.upper():
                    matching_patients.append({"resource": patient_data})
    
    return {
        "resourceType": "Bundle",
        "type": "searchset",
        "total": len(matching_patients),
        "entry": matching_patients
    }


def search_immunization_emr(searchValue, searchParam='patient'):
    """
    Search immunization records for a given patient - MOCK DATA VERSION
    
    Args:
        searchParam (string): Name of search parameter. Currently patient is the only valid value
        searchValue (string): Value of search parameter.
    """
    print(f"Searching mock immunizations for patient: {searchValue}")
    
    matching_immunizations = []
    for immunization in MOCK_IMMUNIZATIONS:
        if searchParam == 'patient':
            patient_ref = immunization.get("patient", {}).get("reference", "")
            if searchValue in patient_ref or patient_ref.endswith(searchValue):
                matching_immunizations.append({"resource": immunization})
    
    return {
        "resourceType": "Bundle",
        "type": "searchset",
        "total": len(matching_immunizations),
        "entry": matching_immunizations
    }


def get_available_slots(dateString):
    """
    Get the details of available appointments slots around the provided datetime - MOCK DATA VERSION
    
    Args:
        date_string: desired date of appointment (yyyy-mm-dd format)
    """
    print(f"Generating mock appointment slots for date: {dateString}")
    
    datetime_object = datetime.strptime(dateString, "%Y-%m-%d")
    
    return {
        "doctor_details": MOCK_PRACTITIONER,
        "available_slots": [
            (datetime_object + timedelta(days=random.choice([-2, -1, 0, 1, 2])) + timedelta(hours=random.randint(9, 17))).isoformat(),
            (datetime_object + timedelta(days=random.choice([-2, -1, 0, 1, 2])) + timedelta(hours=random.randint(9, 17))).isoformat(),
            (datetime_object + timedelta(days=random.choice([-2, -1, 0, 1, 2])) + timedelta(hours=random.randint(9, 17))).isoformat()
        ]
    }


def book_appointment(dateString):
    """
    Book the appointment as per preferred date time - MOCK DATA VERSION
    
    Args:
        date_string: desired date of appointment (yyyy-mm-dd hh:mm format)
    """
    print(f"Booking mock appointment for: {dateString}")
    
    return {
        "message": f"Appointment for the slot dated {dateString} has been booked with confirmation number: {random.randint(10000, 20000)}"
    }


def lambda_handler(event, context):
    print(f"Event: {event}")

    resource = get_named_parameter(event, 'resource')
    httpMethod = get_named_parameter(event, 'httpMethod')
    requestBody = get_named_parameter(event, 'body')
    queryStringParameters = get_named_parameter(event, 'queryStringParameters')

    print(f"Resource: {resource}, requestBody: {requestBody}, queryStringParameters: {queryStringParameters}")

    if resource == '/get_patient_emr' and httpMethod == 'GET':
        patient_id = get_named_parameter(queryStringParameters, 'patient_id')

        if patient_id:
            patientRecord = get_patient_emr(patientId=patient_id)
            responseBody = {'body': {'patientRecord': patientRecord}}
        else:
            responseBody = {'body': 'Missing patient_id parameter'}
    elif resource == '/search_patient_emr' and httpMethod == 'POST':
        address_state = get_named_parameter(json.loads(requestBody), 'address_state')

        if address_state:
            searchResults = search_patient_emr(addressState=address_state)
            responseBody = {'body': {'searchRecords': searchResults}}
        else:
            responseBody = {'body': 'Missing address_state parameter'}
    elif resource == '/search_immunization_emr' and httpMethod == 'POST':
        search_value = get_named_parameter(json.loads(requestBody), 'search_value')

        if search_value:
            searchResults = search_immunization_emr(searchValue=search_value)
            responseBody = {'body': {'searchRecords': searchResults}}
        else:
            responseBody = {'body': 'Missing search_value parameter'}
    elif resource == '/get_available_slots' and httpMethod == 'GET':
        date_string = get_named_parameter(queryStringParameters, 'date_string')

        if date_string:
            slotResults = get_available_slots(dateString=date_string)
            responseBody = {'body': {'searchRecords': slotResults}}
        else:
            responseBody = {'body': 'Missing date_string parameter'}
    elif resource == '/book_appointment' and httpMethod == 'POST':
        date_string = get_named_parameter(json.loads(requestBody), 'date_string')

        if date_string:
            apptConfirmation = book_appointment(dateString=date_string)
            responseBody = {'body': {'confirmation': apptConfirmation}}
        else:
            responseBody = {'body': 'Missing date_string parameter'}

    else:
        responseBody = {'body': 'Invalid resource or httpMethod'}

    res = {
        "isBase64Encoded": False,
        "statusCode": 200,
        "headers": {
            "Content-Type": "*/*"
        },
        "body": json.dumps(responseBody)
    }

    print("Response: {}".format(res))

    return res
